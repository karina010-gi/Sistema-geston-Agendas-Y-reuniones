package gestion.main;

import gestion.clases.Agenda;
import gestion.consola.ConsolaUI;
import gestion.datos.DatosIniciales;
import gestion.gui.MenuPrincipal;
import gestion.persistencia.PersistenciaCSV;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        Agenda agenda = new Agenda("Mi Agenda");

        try {

            if (PersistenciaCSV.existenArchivos()) {

                PersistenciaCSV.cargar(agenda);
                System.out.println("Datos cargados desde archivos CSV.");

            } else {

                DatosIniciales.cargar(agenda);

                System.out.println("No existían archivos CSV. " + "Se cargaron los datos iniciales.");
            }

        } catch (IOException e) {

            System.out.println("Error al cargar los datos: " + e.getMessage());
            DatosIniciales.cargar(agenda);
        }

        String opcion = JOptionPane.showInputDialog(null, "Seleccione el modo de uso:\n" + "1. Consola\n" + "2. Interfaz gráfica", "Sistema de Gestión de Agenda", JOptionPane.QUESTION_MESSAGE);

        if ("1".equals(opcion)) {

            ConsolaUI consola = new ConsolaUI(agenda);
            consola.iniciar();

            try {

                PersistenciaCSV.guardar(agenda);
                System.out.println("Datos guardados correctamente.");

            } catch (IOException e) {

                System.out.println("Error al guardar los datos: " + e.getMessage());
            }

        } else if ("2".equals(opcion)) {

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                new MenuPrincipal(agenda).setVisible(true);
                }
            });

        } else {
            System.out.println("Aplicación finalizada.");
        }
    }
}