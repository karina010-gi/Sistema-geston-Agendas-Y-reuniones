package gestion.gui;

import gestion.clases.Agenda;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MenuActividades extends JFrame {

    private Agenda agenda;

    private final Color ROSA_FONDO = new Color(252, 238, 245);

    private final Color ROSA_BOTON = new Color(246, 200, 221);

    private final Color ROSA_BOTON_HOVER = new Color(241, 181, 210);

    private final Color TEXTO = new Color(95, 75, 86);

    public MenuActividades(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Gestión de Actividades");

        setSize(430, 480);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel principal = new JPanel();

        principal.setBackground(ROSA_FONDO);
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBorder(new EmptyBorder(25, 45, 30, 45));

        JLabel titulo = new JLabel("♡ Gestión de Actividades ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));

        titulo.setForeground(TEXTO);

        principal.add(titulo);

        principal.add(Box.createVerticalStrut(25));

        JButton btnAgregar = crearBoton("Agregar actividad");

        JButton btnListar = crearBoton("Listar actividades");

        JButton btnModificar = crearBoton("Modificar actividad");

        JButton btnEliminar = crearBoton("Eliminar actividad");

        JButton btnBuscar = crearBoton("Buscar actividad");

        JButton btnVolver = crearBoton("Volver");

        principal.add(btnAgregar);
        principal.add(Box.createVerticalStrut(10));

        principal.add(btnListar);
        principal.add(Box.createVerticalStrut(10));

        principal.add(btnModificar);
        principal.add(Box.createVerticalStrut(10));

        principal.add(btnEliminar);
        principal.add(Box.createVerticalStrut(10));

        principal.add(btnBuscar);
        principal.add(Box.createVerticalStrut(20));

        principal.add(btnVolver);

        add(principal);

        btnAgregar.addActionListener(e -> new AgregarActividad(agenda).setVisible(true));

        btnListar.addActionListener(e -> new ListarActividades(agenda).setVisible(true));

        btnModificar.addActionListener(e -> new ModificarActividad(agenda).setVisible(true));

        btnEliminar.addActionListener(e -> new EliminarActividad(agenda).setVisible(true));

        btnBuscar.addActionListener(e -> new BuscarActividad(agenda).setVisible(true));

        btnVolver.addActionListener(e -> dispose());
    }

    private JButton crearBoton(String texto) {

        JButton boton = new JButton(texto);

        boton.setAlignmentX(Component.CENTER_ALIGNMENT);

        boton.setMaximumSize(new Dimension(280, 45));

        boton.setPreferredSize(new Dimension(280, 45));

        boton.setBackground(ROSA_BOTON);

        boton.setForeground(TEXTO);

        boton.setFont(new Font("SansSerif", Font.BOLD, 14));

        boton.setFocusPainted(false);

        boton.setBorder(BorderFactory.createLineBorder(
                        new Color(230, 170, 200), 1));

        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                boton.setBackground(ROSA_BOTON_HOVER);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                boton.setBackground(ROSA_BOTON);
            }
        });

        return boton;
    }
}