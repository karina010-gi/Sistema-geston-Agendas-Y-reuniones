package gestion.gui;

import gestion.clases.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EliminarActividad extends JFrame {

    private Agenda agenda;

    private JTextField txtFecha;
    private JTextField txtId;


    public EliminarActividad(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Eliminar Actividad");
        setSize(470, 330);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel();
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBorder(new EmptyBorder(25, 35, 25, 35));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Eliminar Actividad ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 21));
        principal.add(titulo);
        principal.add(Box.createVerticalStrut(25));

        // ======================================
        // FECHA
        // ======================================

        JPanel filaFecha = new JPanel(new BorderLayout(10, 0));
        JLabel lblFecha = new JLabel("Fecha:");
        txtFecha = new JTextField();
        filaFecha.add(lblFecha, BorderLayout.WEST);
        filaFecha.add(txtFecha, BorderLayout.CENTER);
        principal.add(filaFecha);
        principal.add(Box.createVerticalStrut(15));

        // ======================================
        // ID
        // ======================================

        JPanel filaId = new JPanel(new BorderLayout(10, 0));
        JLabel lblId = new JLabel("ID actividad:");
        txtId = new JTextField();
        filaId.add(lblId, BorderLayout.WEST);
        filaId.add(txtId, BorderLayout.CENTER);
        principal.add(filaId);
        principal.add(Box.createVerticalStrut(8));

        // ======================================
        // AYUDA
        // ======================================

        JLabel ayuda = new JLabel("Formato fecha: dd/MM/yyyy");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        principal.add(ayuda);
        principal.add(Box.createVerticalStrut(20));

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 12, 0));
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCerrar);
        principal.add(panelBotones);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnEliminar.addActionListener(e -> eliminar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }

    // ==========================================
    // LIMPIAR CAMPOS
    // ==========================================

    private void limpiarCampos() {

        txtFecha.setText("");
        txtId.setText("");
    }


    // ==========================================
    // ELIMINAR ACTIVIDAD
    // ==========================================

    private void eliminar() {

        try {

            String textoFecha = txtFecha.getText().trim();
            String textoId = txtId.getText().trim();

            // ==================================
            // VALIDAR CAMPOS VACÍOS
            // ==================================

            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar una fecha.", "Fecha requerida", JOptionPane.WARNING_MESSAGE);
                return;
            }


            if (textoId.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar el ID de la actividad.", "ID requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // FECHA
            // ==================================

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(textoFecha, formato);

            // ==================================
            // ID
            // ==================================

            int id = Integer.parseInt(textoId);

            if (id <= 0) {

                JOptionPane.showMessageDialog(this, "El ID debe ser mayor que cero.", "ID inválido", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // ==================================
            // BUSCAR DÍA
            // ==================================

            Dia dia = agenda.buscarDia(fecha);

            if (dia == null) {

                JOptionPane.showMessageDialog(this, "El día no existe.","Día no encontrado", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // BUSCAR ACTIVIDAD
            // ==================================

            Actividad actividad = dia.buscarActividad(id);

            if (actividad == null) {

                JOptionPane.showMessageDialog(this, "La actividad no existe.", "Actividad no encontrada", JOptionPane.WARNING_MESSAGE);
                return;
            }


            // ==================================
            // CONFIRMACIÓN
            // ==================================

            int respuesta = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar la actividad?\n\n" + "ID: " + actividad.getId() + "\n" + "Título: " + actividad.getTitulo(), "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }

            // ==================================
            // ELIMINAR
            // ==================================

            dia.eliminarActividad(id);
            JOptionPane.showMessageDialog(this, "Actividad eliminada correctamente.");
            limpiarCampos();

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this, "El ID debe ser un número entero.", "ID inválido", JOptionPane.ERROR_MESSAGE);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Revisa los datos ingresados.\n" + "Fecha: dd/MM/yyyy", "Datos inválidos", JOptionPane.ERROR_MESSAGE);
        }
    }
}