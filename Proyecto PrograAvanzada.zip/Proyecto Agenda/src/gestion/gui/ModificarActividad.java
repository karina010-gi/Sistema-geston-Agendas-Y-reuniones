package gestion.gui;

import gestion.clases.*;
import gestion.excepciones.HorarioInvalidoException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ModificarActividad extends JFrame {

    private Agenda agenda;

    private JTextField txtFecha;
    private JTextField txtId;
    private JTextField txtTitulo;
    private JTextField txtDescripcion;
    private JTextField txtInicio;
    private JTextField txtFin;
    private JTextField txtEtiqueta;


    public ModificarActividad(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Modificar Actividad");
        setSize(560, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel(new BorderLayout(0, 15));
        principal.setBorder( new EmptyBorder(25, 30, 25, 30));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Modificar Actividad ♡", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        principal.add(titulo, BorderLayout.NORTH);

        // ======================================
        // FORMULARIO
        // ======================================

        JPanel formulario = new JPanel(new GridLayout(7, 2, 12, 12));

        // FECHA

        formulario.add(new JLabel("Fecha:"));
        txtFecha = new JTextField();
        formulario.add(txtFecha);

        // ID

        formulario.add(new JLabel("ID:"));
        txtId = new JTextField();
        formulario.add(txtId);

        // TÍTULO

        formulario.add(new JLabel("Nuevo título:"));
        txtTitulo = new JTextField();
        formulario.add(txtTitulo);

        // DESCRIPCIÓN

        formulario.add(new JLabel("Nueva descripción:"));
        txtDescripcion = new JTextField();
        formulario.add(txtDescripcion);


        // HORA INICIO

        formulario.add(new JLabel("Nueva hora inicio:"));
        txtInicio = new JTextField();
        formulario.add(txtInicio);

        // HORA FIN

        formulario.add(new JLabel("Nueva hora fin:"));
        txtFin = new JTextField();
        formulario.add(txtFin);

        // ETIQUETA

        formulario.add(new JLabel("Nueva etiqueta:"));
        txtEtiqueta = new JTextField();
        formulario.add(txtEtiqueta);

        // ======================================
        // CENTRO
        // ======================================

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.add(formulario);
        centro.add(Box.createVerticalStrut(15));

        // ======================================
        // AYUDA
        // ======================================

        JLabel ayuda = new JLabel("<html><center>" + "Fecha: dd/MM/yyyy" + " &nbsp;&nbsp; | &nbsp;&nbsp; " + "Hora: HH:mm" + "<br>" + "Ingresa los nuevos datos de la actividad." + "</center></html>");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        centro.add(ayuda);
        principal.add(centro, BorderLayout.CENTER);

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 12, 0));
        JButton btnModificar = new JButton("Modificar");
        JButton btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnModificar);
        panelBotones.add(btnCerrar);
        principal.add(panelBotones, BorderLayout.SOUTH);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnModificar.addActionListener(e -> modificar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }

    // ==========================================
    // LIMPIAR CAMPOS
    // ==========================================

    private void limpiarCampos() {

        txtFecha.setText("");
        txtId.setText("");
        txtTitulo.setText("");
        txtDescripcion.setText("");
        txtInicio.setText("");
        txtFin.setText("");
        txtEtiqueta.setText("");
    }

    // ==========================================
    // MODIFICAR ACTIVIDAD
    // ==========================================

    private void modificar() {

        try {

            // ==================================
            // OBTENER DATOS
            // ==================================

            String textoFecha = txtFecha.getText().trim();
            String textoId = txtId.getText().trim();
            String titulo = txtTitulo.getText().trim();
            String descripcion = txtDescripcion.getText().trim();
            String textoInicio = txtInicio.getText().trim();
            String textoFin = txtFin.getText().trim();
            String textoEtiqueta = txtEtiqueta.getText().trim();

            // ==================================
            // VALIDAR CAMPOS VACÍOS
            // ==================================

            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar una fecha.", "Fecha requerida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (textoId.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar el ID de la actividad.", "ID requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (titulo.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar el nuevo título.", "Título requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (textoInicio.isEmpty() || textoFin.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar la hora de inicio " + "y la hora de término.", "Horario requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (textoEtiqueta.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar una etiqueta.", "Etiqueta requerida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // FECHA
            // ==================================

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(textoFecha, formato);

            // ==================================
            // ID
            // ==================================

            int id = Integer.parseInt(textoId);
            if (id <= 0) {

                JOptionPane.showMessageDialog(this, "El ID debe ser mayor que cero.", "ID inválido", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // ==================================
            // BUSCAR DÍA
            // ==================================

            Dia dia = agenda.buscarDia(fecha);
            if (dia == null) {

                JOptionPane.showMessageDialog(this, "El día no existe.", "Día no encontrado", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // BUSCAR ACTIVIDAD
            // ==================================

            Actividad anterior = dia.buscarActividad(id);
            if (anterior == null) {

                JOptionPane.showMessageDialog(this, "La actividad no existe.", "Actividad no encontrada", JOptionPane.WARNING_MESSAGE);
                return;
            }


            // ==================================
            // HORAS
            // ==================================

            LocalTime inicio = LocalTime.parse(textoInicio);
            LocalTime fin = LocalTime.parse(textoFin);

            // ==================================
            // ETIQUETA
            // ==================================

            Etiqueta etiqueta = new Etiqueta(textoEtiqueta, "");

            // ==================================
            // CREAR ACTIVIDAD MODIFICADA
            // ==================================

            Actividad nueva;

            if (anterior instanceof Reunion) {

                Reunion reunion = (Reunion) anterior;
                nueva = new Reunion(id, titulo, descripcion, inicio, fin, etiqueta, reunion.getLugar());

            } else {

                nueva = new EventoPersonal(id, titulo, descripcion, inicio, fin, etiqueta);
            }

            // ==================================
            // MODIFICAR
            // ==================================

            dia.modificarActividad(nueva);

            JOptionPane.showMessageDialog(this, "Actividad modificada correctamente.");
            limpiarCampos();

        } catch (HorarioInvalidoException e) {

            JOptionPane.showMessageDialog(this, e.getMessage(), "Horario inválido", JOptionPane.ERROR_MESSAGE);

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this, "El ID debe ser un número entero.", "ID inválido", JOptionPane.ERROR_MESSAGE);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Revisa los datos ingresados.\n" + "Fecha: dd/MM/yyyy\n" + "Hora: HH:mm", "Datos inválidos", JOptionPane.ERROR_MESSAGE);
        }
    }
}