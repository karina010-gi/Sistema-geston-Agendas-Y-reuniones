package gestion.gui;

import gestion.clases.Agenda;
import gestion.excepciones.FechaDuplicadaException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ModificarDia extends JFrame {

    private Agenda agenda;

    private JTextField txtActual;
    private JTextField txtNueva;

    public ModificarDia(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Modificar Día");
        setSize(470, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel();
        principal.setLayout( new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBorder(new EmptyBorder(25, 35, 25, 35));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Modificar Día ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        principal.add(titulo);
        principal.add(Box.createVerticalStrut(25));

        // ======================================
        // FECHA ACTUAL
        // ======================================

        JPanel filaActual = new JPanel(new BorderLayout(10, 0));
        JLabel lblActual = new JLabel("Fecha actual:");
        txtActual = new JTextField();
        filaActual.add(lblActual, BorderLayout.WEST);
        filaActual.add(txtActual, BorderLayout.CENTER);
        principal.add(filaActual);
        principal.add(Box.createVerticalStrut(15));

        // ======================================
        // NUEVA FECHA
        // ======================================

        JPanel filaNueva = new JPanel(new BorderLayout(10, 0));

        JLabel lblNueva = new JLabel("Nueva fecha:");
        txtNueva = new JTextField();
        filaNueva.add(lblNueva, BorderLayout.WEST);
        filaNueva.add(txtNueva, BorderLayout.CENTER);
        principal.add(filaNueva);
        principal.add(Box.createVerticalStrut(8));

        // ======================================
        // AYUDA DE FORMATO
        // ======================================

        JLabel ayuda = new JLabel("Formato: dd/MM/yyyy");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        ayuda.setForeground(EstiloUI.TEXTO);
        principal.add(ayuda);
        principal.add(Box.createVerticalStrut(20));

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 12, 0));

        JButton btnModificar = new JButton("Modificar");
        JButton btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnModificar);
        panelBotones.add(btnCerrar);
        principal.add(panelBotones);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnModificar.addActionListener(e -> modificar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }

    // ==========================================
    // MODIFICAR DÍA
    // ==========================================

    private void modificar() {

        try {

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String textoActual = txtActual.getText().trim();
            String textoNueva = txtNueva.getText().trim();

            // ==================================
            // VALIDAR CAMPOS VACÍOS
            // ==================================

            if (textoActual.isEmpty() || textoNueva.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar ambas fechas.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            LocalDate actual = LocalDate.parse(textoActual, formato);
            LocalDate nueva = LocalDate.parse(textoNueva, formato);

            // ==================================
            // VALIDAR QUE EL DÍA EXISTA
            // ==================================

            if (agenda.buscarDia(actual) == null) {
                JOptionPane.showMessageDialog(this, "El día que desea modificar no existe.", "Día no encontrado", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // MODIFICAR
            // ==================================

            agenda.modificarDia(actual, nueva);
            JOptionPane.showMessageDialog(this, "Día modificado correctamente.");

            // LIMPIAR CAMPOS

            txtActual.setText("");
            txtNueva.setText("");

        } catch (FechaDuplicadaException e) {

            JOptionPane.showMessageDialog(this, e.getMessage(), "Fecha duplicada", JOptionPane.ERROR_MESSAGE);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Fecha inválida.\n" + "Use el formato dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}