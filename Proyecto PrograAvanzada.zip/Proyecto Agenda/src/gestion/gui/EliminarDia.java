package gestion.gui;

import gestion.clases.Agenda;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EliminarDia extends JFrame {

    private Agenda agenda;
    private JTextField txtFecha;

    public EliminarDia(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Eliminar Día");
        setSize(430, 260);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel();
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBorder(new EmptyBorder(25, 35, 25, 35));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Eliminar Día ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        principal.add(titulo);
        principal.add(Box.createVerticalStrut(25));

        // ======================================
        // CAMPO FECHA
        // ======================================

        JPanel filaFecha = new JPanel(new BorderLayout(10, 0));
        JLabel lblFecha = new JLabel("Fecha:");
        txtFecha = new JTextField();
        filaFecha.add(lblFecha, BorderLayout.WEST);
        filaFecha.add(txtFecha, BorderLayout.CENTER);
        principal.add(filaFecha);
        principal.add(Box.createVerticalStrut(8));

        // ======================================
        // AYUDA
        // ======================================

        JLabel ayuda = new JLabel("Formato: dd/MM/yyyy");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        principal.add(ayuda);
        principal.add(Box.createVerticalStrut(20));

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 12, 0));
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCerrar);
        principal.add(panelBotones);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnEliminar.addActionListener(e -> eliminar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }


    // ==========================================
    // ELIMINAR DÍA
    // ==========================================

    private void eliminar() {

        try {

            String textoFecha = txtFecha.getText().trim();
            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar una fecha.", "Fecha requerida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(textoFecha, formato);

            // ==================================
            // VALIDAR EXISTENCIA
            // ==================================

            if (agenda.buscarDia(fecha) == null) {

                JOptionPane.showMessageDialog(this, "El día no existe.", "Día no encontrado", JOptionPane.WARNING_MESSAGE);
                return;
            }


            // ==================================
            // CONFIRMACIÓN
            // ==================================

            int respuesta = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar el día " + fecha.format(formato) + "?\n" + "También se eliminarán sus actividades.", "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }

            // ==================================
            // ELIMINAR
            // ==================================

            agenda.eliminarDia(fecha);
            JOptionPane.showMessageDialog(this, "Día eliminado correctamente.");
            txtFecha.setText("");

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Fecha inválida.\n" + "Use el formato dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE
            );
        }
    }
}