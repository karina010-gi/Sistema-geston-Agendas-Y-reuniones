package gestion.gui;

import gestion.clases.Agenda;
import gestion.persistencia.PersistenciaCSV;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class MenuPrincipal extends JFrame {

    private Agenda agenda;
    private final Color ROSA_FONDO = new Color(252, 238, 245);
    private final Color ROSA_PANEL = new Color(255, 247, 251);
    private final Color ROSA_BOTON = new Color(246, 200, 221);
    private final Color ROSA_HOVER = new Color(241, 181, 210);
    private final Color TEXTO = new Color(95, 75, 86);

    public MenuPrincipal(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Sistema de Gestión de Agenda");
        setSize(500, 680);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // ======================================
        // PANEL GENERAL
        // ======================================

        PanelConFondo fondo = new PanelConFondo("gestion/recursos/fondo_polka.jpg");
        fondo.setBorder(new EmptyBorder(20, 35, 30, 35));

        // ======================================
        // ENCABEZADO
        // ======================================

        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Mi Agenda ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 28));
        titulo.setForeground(TEXTO);

        // ======================================
        // IMAGEN CHIIKAWA
        // ======================================

        JLabel imagenChiikawa = new JLabel();
        imagenChiikawa.setAlignmentX(Component.CENTER_ALIGNMENT);

        try {

            java.net.URL rutaImagen = getClass().getClassLoader().getResource("gestion/recursos/chiikawa.png");
            if (rutaImagen != null) {
                ImageIcon iconoOriginal = new ImageIcon(rutaImagen);
                Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(150, 112, Image.SCALE_SMOOTH);
                imagenChiikawa.setIcon(new ImageIcon(imagenEscalada));

            } else {

                System.out.println("No se encontró " + "gestion/recursos/chiikawa.png");
            }

        } catch (Exception e) {

            System.out.println("Error al cargar la imagen: " + e.getMessage());
        }

        // ======================================
        // SUBTÍTULO
        // ======================================

        JLabel subtitulo = new JLabel("Organiza tus días de forma bonita");
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitulo.setForeground(new Color(140, 110, 125));


        // ======================================
        // ARMAR ENCABEZADO
        // ======================================

        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(8));
        encabezado.add(imagenChiikawa);
        encabezado.add(Box.createVerticalStrut(6));
        encabezado.add(subtitulo);
        encabezado.add(Box.createVerticalStrut(20));
        fondo.add(encabezado, BorderLayout.NORTH);

        // ======================================
        // PANEL CENTRAL
        // ======================================

        JPanel centro = new JPanel();
        centro.setBackground(ROSA_PANEL);
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(240, 205, 220), 1), new EmptyBorder(30, 45, 30, 45)));

        // ======================================
        // BOTONES PRINCIPALES
        // ======================================

        JButton btnDias = crearBoton("♡ Gestión de días");
        JButton btnActividades = crearBoton("♡ Gestión de actividades");
        JButton btnConsultar = crearBoton("☆ Consultar agenda");
        JButton btnSalir = crearBoton("Salir");

        // ======================================
        // ORGANIZAR BOTONES
        // Todos con la misma separación
        // ======================================

        centro.add(btnDias);
        centro.add(Box.createVerticalStrut(15));
        centro.add(btnActividades);
        centro.add(Box.createVerticalStrut(15));
        centro.add(btnConsultar);
        centro.add(Box.createVerticalStrut(15));
        centro.add(btnSalir);
        fondo.add(centro, BorderLayout.CENTER);
        add(fondo);

        // ======================================
        // ACCIONES
        // ======================================

        btnDias.addActionListener(e -> new MenuDias(agenda).setVisible(true));
        btnActividades.addActionListener(e -> new MenuActividades(agenda).setVisible(true));
        btnConsultar.addActionListener(e -> new ConsultarAgenda(agenda).setVisible(true));
        btnSalir.addActionListener(e -> guardarYSalir());

        // ======================================
        // CERRAR CON X
        // ======================================

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                guardarYSalir();
            }
        });
    }


    // ==========================================
    // CREAR BOTÓN
    // ==========================================

    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(320, 55));
        boton.setPreferredSize(new Dimension(320, 55));
        boton.setBackground(ROSA_BOTON);
        boton.setForeground(TEXTO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 15));
        boton.setFocusPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setBorder(BorderFactory.createLineBorder(new Color(230, 170, 200), 1));

        // ======================================
        // EFECTO AL PASAR EL MOUSE
        // ======================================

        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                boton.setBackground(ROSA_HOVER);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                boton.setBackground(ROSA_BOTON);
            }
        });
        return boton;
    }

    // ==========================================
    // GUARDAR Y SALIR
    // ==========================================

    private void guardarYSalir() {

        try {

            PersistenciaCSV.guardar(agenda);
            System.out.println("Datos guardados correctamente en CSV.");
            System.exit(0);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this, "No se pudieron guardar los datos:\n" + e.getMessage(), "Error al guardar", JOptionPane.ERROR_MESSAGE);
        }
    }
}