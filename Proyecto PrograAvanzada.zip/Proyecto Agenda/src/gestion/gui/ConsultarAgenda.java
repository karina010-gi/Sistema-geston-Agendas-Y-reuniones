package gestion.gui;

import gestion.clases.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ConsultarAgenda extends JFrame {

    private Agenda agenda;

    private JTextField txtInicio;
    private JTextField txtFin;
    private JTextField txtEtiqueta;

    private JTextArea area;


    public ConsultarAgenda(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Consultar Agenda");
        setSize(620, 540);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel(new BorderLayout(0, 15));
        principal.setBorder(new EmptyBorder(25, 30, 25, 30));

        // ======================================
        // ENCABEZADO
        // ======================================

        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("♡ Consultar Agenda ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(20));

        // ======================================
        // FORMULARIO
        // ======================================

        JPanel formulario = new JPanel(new GridLayout(3, 2, 12, 12));

        // FECHA INICIO

        formulario.add(new JLabel("Fecha inicio:"));
        txtInicio = new JTextField();
        formulario.add(txtInicio);

        // FECHA FIN

        formulario.add(new JLabel("Fecha fin:"));
        txtFin = new JTextField();
        formulario.add(txtFin);

        // ETIQUETA

        formulario.add(new JLabel("Etiqueta:"));
        txtEtiqueta = new JTextField();
        formulario.add(txtEtiqueta);
        encabezado.add(formulario);
        encabezado.add(Box.createVerticalStrut(10));

        // ======================================
        // AYUDA
        // ======================================

        JLabel ayuda = new JLabel("<html><center>" + "Formato de fecha: dd/MM/yyyy" + "<br>" + "La consulta mostrará las actividades " + "del período que coincidan con la etiqueta." + "</center></html>");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        encabezado.add(ayuda);
        principal.add(encabezado, BorderLayout.NORTH);

        // ======================================
        // ÁREA DE RESULTADOS
        // ======================================

        area = new JTextArea();
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new Insets(15, 15, 15, 15));
        JScrollPane scroll = new JScrollPane(area);
        principal.add(scroll, BorderLayout.CENTER);

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 12, 0));
        JButton btnConsultar = new JButton("Consultar");
        JButton btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnConsultar);
        panelBotones.add(btnCerrar);
        principal.add(panelBotones, BorderLayout.SOUTH);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnConsultar.addActionListener(e -> consultar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }


    // ==========================================
    // CONSULTAR
    // ==========================================

    private void consultar() {

        try {

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String textoInicio = txtInicio.getText().trim();
            String textoFin = txtFin.getText().trim();
            String etiqueta = txtEtiqueta.getText().trim();

            // ==================================
            // VALIDAR CAMPOS
            // ==================================

            if (textoInicio.isEmpty() || textoFin.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar ambas fechas.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (etiqueta.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Debe ingresar una etiqueta.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ==================================
            // CONVERTIR FECHAS
            // ==================================

            LocalDate inicio = LocalDate.parse(textoInicio, formato);
            LocalDate fin = LocalDate.parse(textoFin, formato);

            // ==================================
            // VALIDAR RANGO
            // ==================================

            if (fin.isBefore(inicio)) {

                JOptionPane.showMessageDialog(this, "La fecha final no puede ser anterior " + "a la fecha inicial.", "Rango inválido", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // ==================================
            // CONSULTA
            // ==================================

            List<ActividadProgramada> actividades = agenda.consultarActividadesPorPeriodoYEtiqueta(inicio, fin, etiqueta);
            area.setText("");

            // ==================================
            // SIN RESULTADOS
            // ==================================

            if (actividades.isEmpty()) {

                area.setText("♡ Sin resultados ♡\n\n" + "No se encontraron actividades " + "entre " + inicio.format(formato) + " y " + fin.format(formato) + " con la etiqueta \"" + etiqueta + "\".");
                return;
            }

            // ==================================
            // ENCABEZADO RESULTADO
            // ==================================

            area.setText("♡ RESULTADOS DE LA CONSULTA ♡\n\n" + "Período: " + inicio.format(formato) + " - " + fin.format(formato) + "\n" + "Etiqueta: " + etiqueta + "\n\n" + "========================================" + "\n\n");

            // ==================================
            // MOSTRAR ACTIVIDADES
            // ==================================

            for (ActividadProgramada ap : actividades) {

                Actividad actividad = ap.getActividad();
                area.append("Fecha: " + ap.getFecha().format(formato) + "\n");
                area.append("Hora: " + actividad.getHoraInicio() + " - " + actividad.getHoraFin() + "\n");
                area.append("Título: " + actividad.getTitulo() + "\n");
                area.append("Descripción: " + actividad.getDescripcion() + "\n");

                if (actividad.getEtiqueta() != null) {

                    area.append("Etiqueta: " + actividad.getEtiqueta().getNombre() + "\n");
                }


                area.append(actividad.mostrarDetalle() + "\n");
                area.append("\n" + "----------------------------------------" + "\n\n");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Fecha inválida.\n" + "Use el formato dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}