package gestion.gui;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EstiloUI {

    public static final Color ROSA_FONDO = new Color(252, 238, 245);

    public static final Color ROSA_PANEL = new Color(255, 247, 251);

    public static final Color ROSA_BOTON = new Color(246, 200, 221);

    public static final Color ROSA_HOVER = new Color(241, 181, 210);

    public static final Color ROSA_BORDE = new Color(230, 170, 200);

    public static final Color CAMPO = new Color(255, 250, 252);

    public static final Color TEXTO = new Color(95, 75, 86);

    private EstiloUI() {
    }

    public static void aplicar(JFrame ventana) {

        ventana.getContentPane().setBackground(ROSA_FONDO);

        aplicarRecursivamente(ventana.getContentPane());
    }

    private static void aplicarRecursivamente(Container contenedor) {

        contenedor.setBackground(ROSA_FONDO);

        for (Component componente : contenedor.getComponents()) {

            if (componente instanceof JPanel) {

                componente.setBackground(ROSA_FONDO);
            }

            if (componente instanceof JLabel) {

                JLabel label = (JLabel) componente;
                label.setForeground(TEXTO);
                label.setFont(new Font("SansSerif", Font.BOLD, 13)
                );
            }

            if (componente instanceof JButton) {

                estilizarBoton((JButton) componente);
            }

            if (componente instanceof JTextField) {

                JTextField campo = (JTextField) componente;
                campo.setBackground(CAMPO);
                campo.setForeground(TEXTO);
                campo.setCaretColor(TEXTO);
                campo.setFont(new Font("SansSerif", Font.PLAIN, 13));
                campo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ROSA_BORDE, 1), BorderFactory.createEmptyBorder(5, 7, 5, 7)));
            }

            if (componente instanceof JTextArea) {

                JTextArea area = (JTextArea) componente;
                area.setBackground( CAMPO);
                area.setForeground(TEXTO);
                area.setCaretColor(TEXTO);
                area.setFont(new Font("SansSerif", Font.PLAIN, 13));
            }

            if (componente instanceof JComboBox) {

                JComboBox combo = (JComboBox) componente;

                combo.setBackground(CAMPO);
                combo.setForeground(TEXTO);
            }

            if (componente instanceof JScrollPane) {

                JScrollPane scroll = (JScrollPane) componente;
                scroll.setBorder(BorderFactory.createLineBorder(ROSA_BORDE));
                scroll.getViewport().setBackground(CAMPO);
            }

            if (componente instanceof Container) {

                aplicarRecursivamente((Container) componente);
            }
        }
    }

    public static void estilizarBoton(JButton boton) {

        boton.setBackground(ROSA_BOTON);
        boton.setForeground(TEXTO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 13));
        boton.setFocusPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Border borde = BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ROSA_BORDE, 1), BorderFactory.createEmptyBorder(8, 12, 8, 12));
        boton.setBorder(borde );
        boton.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(ROSA_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(ROSA_BOTON);
            }
        });
    }
}