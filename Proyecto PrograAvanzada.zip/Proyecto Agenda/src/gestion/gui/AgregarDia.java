package gestion.gui;

import gestion.clases.Agenda;
import gestion.excepciones.FechaDuplicadaException;
import gestion.persistencia.PersistenciaCSV;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AgregarDia extends JFrame {

    private Agenda agenda;
    private JTextField txtFecha;

    public AgregarDia(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Agregar Día");
        setSize(420, 240);

        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(25, 35, 25, 35));

        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo = new JLabel("♡ Agregar Día ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel.add(titulo);
        panel.add(Box.createVerticalStrut(20));

        // ======================================
        // FECHA
        // ======================================

        JPanel filaFecha = new JPanel(new BorderLayout(10, 0));
        JLabel lblFecha = new JLabel("Fecha (dd/MM/yyyy):");
        txtFecha = new JTextField();
        filaFecha.add(lblFecha, BorderLayout.WEST);
        filaFecha.add(txtFecha, BorderLayout.CENTER);
        panel.add(filaFecha);
        panel.add(Box.createVerticalStrut(20));

        // ======================================
        // BOTONES
        // ======================================

        JPanel filaBotones = new JPanel(new GridLayout(1, 2, 12, 0));
        JButton btnAgregar = new JButton("Agregar");
        JButton btnCerrar = new JButton("Cerrar");
        filaBotones.add(btnAgregar);
        filaBotones.add(btnCerrar);
        panel.add(filaBotones);
        add(panel);


        // ======================================
        // ACCIONES
        // ======================================

        btnAgregar.addActionListener(e -> agregar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }


    // ==========================================
    // AGREGAR DÍA
    // ==========================================

    private void agregar() {

        try {

            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            LocalDate fecha = LocalDate.parse(txtFecha.getText().trim(), formato);
            agenda.agregarDia(fecha);
            PersistenciaCSV.guardar(agenda);
            JOptionPane.showMessageDialog(this, "Día agregado y guardado correctamente.");
            txtFecha.setText("");

        } catch (FechaDuplicadaException e) {

            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this, "El día fue agregado, " + "pero ocurrió un error al guardar:\n" + e.getMessage(), "Error de persistencia", JOptionPane.ERROR_MESSAGE);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Formato de fecha inválido. " + "Use dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}