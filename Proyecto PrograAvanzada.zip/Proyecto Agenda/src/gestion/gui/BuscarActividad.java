package gestion.gui;

import gestion.clases.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;

public class BuscarActividad extends JFrame {

    private Agenda agenda;

    private JTextField txtBusqueda;
    private JTextArea area;

    private JComboBox<String> comboTipo;


    public BuscarActividad(Agenda agenda) {

        this.agenda = agenda;
        setTitle("Buscar Actividad");
        setSize(520, 430);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal = new JPanel(new BorderLayout(0, 15));
        principal.setBorder(new EmptyBorder(25, 30, 25, 30));

        // ======================================
        // ENCABEZADO
        // ======================================

        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        JLabel titulo = new JLabel("♡ Buscar Actividad ♡");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 21));
        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(20));

        // ======================================
        // FILA DE BÚSQUEDA
        // ======================================

        JPanel filaBusqueda = new JPanel(new BorderLayout(10, 0));
        comboTipo = new JComboBox<>(new String[]{"ID", "Título"});
        txtBusqueda = new JTextField();
        JButton btnBuscar = new JButton("Buscar");
        filaBusqueda.add(comboTipo, BorderLayout.WEST);
        filaBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        filaBusqueda.add(btnBuscar, BorderLayout.EAST);
        encabezado.add(filaBusqueda);
        encabezado.add(Box.createVerticalStrut(7));

        // ======================================
        // AYUDA
        // ======================================

        JLabel ayuda = new JLabel("Puedes buscar por ID o por título");
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 11));
        encabezado.add(ayuda);
        principal.add(encabezado, BorderLayout.NORTH);

        // ======================================
        // RESULTADO
        // ======================================

        area = new JTextArea();
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new Insets(15,15, 15, 15));
        JScrollPane scroll = new JScrollPane(area);
        principal.add(scroll, BorderLayout.CENTER);

        // ======================================
        // BOTÓN CERRAR
        // ======================================

        JPanel panelInferior = new JPanel(new BorderLayout());
        JButton btnCerrar = new JButton("Cerrar");
        panelInferior.add(btnCerrar, BorderLayout.CENTER);
        principal.add(panelInferior, BorderLayout.SOUTH);
        add(principal);

        // ======================================
        // ACCIONES
        // ======================================

        btnBuscar.addActionListener(e -> buscar());
        btnCerrar.addActionListener(e -> dispose());

        // ======================================
        // CAMBIO DE TEXTO DE AYUDA
        // ======================================

        comboTipo.addActionListener(e -> {

                    if (comboTipo.getSelectedItem().equals("ID")) {
                        txtBusqueda.setToolTipText("Ingrese un ID numérico");

                    } else {

                        txtBusqueda.setToolTipText("Ingrese el título de la actividad");
                    }
                });


        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(this);
    }


    // ==========================================
    // BUSCAR ACTIVIDAD
    // ==========================================

    private void buscar() {

        String texto = txtBusqueda.getText().trim();
        Actividad actividad = null;

        // ======================================
        // BÚSQUEDA POR ID
        // ======================================

        if (comboTipo.getSelectedItem().equals("ID")) {

            if (texto.isEmpty()) {

                area.setText("♡ Ingrese un ID para realizar la búsqueda.");
                return;
            }


            try {

                int id = Integer.parseInt(texto);

                if (id <= 0) {

                    area.setText("♡ El ID debe ser mayor que cero.");
                    return;
                }

                actividad = agenda.buscarActividadPorId(id);

            } catch (NumberFormatException e) {

                area.setText("♡ El ID debe ser un número entero.");
                return;
            }


        // ======================================
        // BÚSQUEDA POR TÍTULO
        // ======================================

        } else {

            if (texto.isEmpty()) {

                area.setText("♡ Debe ingresar un título.");
                return;
            }


            actividad = agenda.buscarActividadPorTitulo(texto);
        }


        // ======================================
        // NO ENCONTRADA
        // ======================================

        if (actividad == null) {

            area.setText("♡ Actividad no encontrada\n\n" + "No existe una actividad " + "que coincida con la búsqueda.");
            return;
        }

        // ======================================
        // MOSTRAR RESULTADO
        // ======================================

        area.setText("♡ ACTIVIDAD ENCONTRADA ♡\n\n" + "ID: " + actividad.getId() + "\n\n" + "Título: " + actividad.getTitulo() + "\n\n" + "Descripción: " + actividad.getDescripcion() + "\n\n" + "Horario: " + actividad.getHoraInicio() + " - " + actividad.getHoraFin());

        if (actividad.getEtiqueta() != null) {

            area.append("\n\nEtiqueta: " + actividad.getEtiqueta().getNombre());
        }

        area.append("\n\n" + actividad.mostrarDetalle());
    }
}