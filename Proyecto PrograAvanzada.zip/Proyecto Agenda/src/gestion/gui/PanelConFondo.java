package gestion.gui;

import javax.swing.*;
import java.awt.*;

public class PanelConFondo extends JPanel {

    private Image imagenFondo;

    public PanelConFondo(String rutaImagen) {

        java.net.URL url = getClass().getClassLoader().getResource(rutaImagen);
        if (url != null) {

            imagenFondo = new ImageIcon(url).getImage();
        }

        setLayout(new BorderLayout());
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        if (imagenFondo != null) {

            g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
        }
    }
}