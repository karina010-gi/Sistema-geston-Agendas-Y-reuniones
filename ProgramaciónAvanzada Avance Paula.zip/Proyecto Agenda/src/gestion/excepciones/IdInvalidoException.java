package gestion.excepciones;

public class IdInvalidoException extends Exception {

    public IdInvalidoException(String mensaje) {
        super(mensaje);
    }
}