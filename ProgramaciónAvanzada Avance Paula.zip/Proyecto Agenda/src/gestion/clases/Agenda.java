package gestion.clases;

import gestion.excepciones.FechaDuplicadaException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Agenda {

    private String nombre;
    
     /**
     * Primera colección principal del sistema.
     * Almacena los días de la agenda utilizando la fecha como clave.
     *
     * Cada objeto Dia contiene internamente una segunda colección
     * de actividades, formando así la estructura de colecciones anidadas.
     */

    private HashMap<LocalDate, Dia> dias;

    public Agenda(String nombre) {
        this.nombre = nombre;
        this.dias = new HashMap<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Map<LocalDate, Dia> getDias() {
        return Collections.unmodifiableMap(dias);
    }

    public void setDias(HashMap<LocalDate, Dia> dias) {

        if (dias == null) {
            this.dias = new HashMap<>();
        } else {
            this.dias = new HashMap<>(dias);
        }
    }

    public void agregarDia(LocalDate fecha)
            throws FechaDuplicadaException {

        if (dias.containsKey(fecha)) {
            throw new FechaDuplicadaException(
                    "La fecha ya existe en la agenda."
            );
        }

        Dia nuevoDia = new Dia(fecha);
        dias.put(fecha, nuevoDia);
    }

    public Dia buscarDia(LocalDate fecha) {
        return dias.get(fecha);
    }

    public void eliminarDia(LocalDate fecha) {
        dias.remove(fecha);
    }

    /**
    * Busca las actividades correspondientes a una fecha específica.
    * Este método forma parte de la sobrecarga de buscarActividades.
    *
    * @param fecha fecha que se desea consultar
    * @return lista de actividades del día
    */

    public List<ActividadProgramada>
            consultarActividadesPorPeriodoYEtiqueta(
                    LocalDate inicio,
                    LocalDate fin,
                    String nombreEtiqueta) {

        List<ActividadProgramada> resultado =
                new ArrayList<>();

        for (Dia dia : dias.values()) {

            if (!dia.getFecha().isBefore(inicio)
                    && !dia.getFecha().isAfter(fin)) {

                for (Actividad actividad
                        : dia.getActividades()) {

                    if (actividad.getEtiqueta() != null
                            && actividad.getEtiqueta()
                            .getNombre()
                            .equalsIgnoreCase(
                                    nombreEtiqueta)) {

                        resultado.add(
                                new ActividadProgramada(
                                        dia.getFecha(),
                                        actividad
                                )
                        );
                    }
                }
            }
        }

        resultado.sort(
                (ap1, ap2) -> {

                    int comparacionFecha =
                            ap1.getFecha()
                            .compareTo(
                                    ap2.getFecha()
                            );

                    if (comparacionFecha != 0) {
                        return comparacionFecha;
                    }

                    return ap1.getActividad()
                            .getHoraInicio()
                            .compareTo(
                                    ap2.getActividad()
                                    .getHoraInicio()
                            );
                }
        );

        return resultado;
    }
    /**
    * Busca actividades dentro de un período de fechas.
    * Sobrecarga del método buscarActividades.
    *
    * @param inicio fecha inicial del período
    * @param fin fecha final del período
    * @return actividades encontradas dentro del período
    */

    public List<Actividad> buscarActividades(
            LocalDate inicio, LocalDate fin) {

        List<Actividad> resultado = new ArrayList<>();

        for (Dia dia : dias.values()) {

            LocalDate fecha = dia.getFecha();

            if (!fecha.isBefore(inicio)
                    && !fecha.isAfter(fin)) {

                resultado.addAll(dia.getActividades());
            }
        }

        return resultado;
    }

    public List<Actividad> filtrarPorEtiqueta(String nombreEtiqueta) {

        List<Actividad> resultado = new ArrayList<>();

        for (Dia dia : dias.values()) {

            for (Actividad actividad : dia.getActividades()) {

                if (actividad.getEtiqueta() != null
                        && actividad.getEtiqueta()
                        .getNombre()
                        .equalsIgnoreCase(nombreEtiqueta)) {

                    resultado.add(actividad);
                }
            }
        }

        return resultado;
    }

    public boolean existeActividadConId(int id) {
        for (Dia dia : dias.values()) {

            if (dia.buscarActividad(id) != null) {
                return true;
            }
        }

        return false;
    }

    public Actividad buscarActividadPorId(int id) {

        for (Dia dia : dias.values()) {

            Actividad actividad = dia.buscarActividad(id);

            if (actividad != null) {
                return actividad;
            }
        }

        return null;
    }

    public Actividad buscarActividadPorTitulo(String titulo) {

        for (Dia dia : dias.values()) {

            List<Actividad> resultado =
                    dia.buscarActividad(titulo);

            if (!resultado.isEmpty()) {
                return resultado.get(0);
            }
        }

        return null;
    }
    
    public void modificarDia(LocalDate fechaActual, LocalDate nuevaFecha)
        throws FechaDuplicadaException {

        if (!dias.containsKey(fechaActual)) {
            return;
        }

        if (dias.containsKey(nuevaFecha)) {
            throw new FechaDuplicadaException(
                    "La nueva fecha ya existe en la agenda."
            );
        }

        Dia dia = dias.remove(fechaActual);

        dia.setFecha(nuevaFecha);

        dias.put(nuevaFecha, dia);
    }

    
    public List<Actividad> buscarActividades(LocalDate fecha) {

        Dia dia = dias.get(fecha);

        if (dia == null) {
            return new ArrayList<>();
        }

        return new ArrayList<>(
                dia.getActividades()
        );
    }
}