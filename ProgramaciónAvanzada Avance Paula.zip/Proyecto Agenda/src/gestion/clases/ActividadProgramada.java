package gestion.clases;

import java.time.LocalDate;

public class ActividadProgramada {

    private LocalDate fecha;
    private Actividad actividad;

    public ActividadProgramada(
            LocalDate fecha,
            Actividad actividad) {

        this.fecha = fecha;
        this.actividad = actividad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Actividad getActividad() {
        return actividad;
    }

    public void setActividad(Actividad actividad) {
        this.actividad = actividad;
    }
}