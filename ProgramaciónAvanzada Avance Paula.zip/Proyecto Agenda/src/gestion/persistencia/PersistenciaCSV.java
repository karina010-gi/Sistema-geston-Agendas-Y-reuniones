package gestion.persistencia;

import gestion.clases.Actividad;
import gestion.clases.Agenda;
import gestion.clases.Dia;
import gestion.clases.Etiqueta;
import gestion.clases.EventoPersonal;
import gestion.clases.Participante;
import gestion.clases.Reunion;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.time.LocalDate;
import java.time.LocalTime;

import java.util.Map;

public class PersistenciaCSV {

    // ==========================================
    // RUTAS DE LOS ARCHIVOS
    // ==========================================

    private static final String CARPETA =
            "datos";

    private static final String ARCHIVO_DIAS =
            CARPETA
            + File.separator
            + "dias.csv";

    private static final String ARCHIVO_ACTIVIDADES =
            CARPETA
            + File.separator
            + "actividades.csv";


    // ==========================================
    // CONSTRUCTOR PRIVADO
    // ==========================================

    private PersistenciaCSV() {

        // Esta clase solamente contiene
        // métodos estáticos.
    }


    // ==========================================
    // CREAR CARPETA
    // ==========================================

    private static void crearCarpeta() {

        File carpeta =
                new File(CARPETA);

        if (!carpeta.exists()) {

            carpeta.mkdirs();
        }
    }


    // ==========================================
    // VERIFICAR SI EXISTEN LOS ARCHIVOS
    // ==========================================

    public static boolean existenArchivos() {

        File archivoDias =
                new File(ARCHIVO_DIAS);

        File archivoActividades =
                new File(ARCHIVO_ACTIVIDADES);

        return archivoDias.exists()
                && archivoActividades.exists();
    }


    // ==========================================
    // GUARDAR TODO
    // ==========================================

    public static void guardar(Agenda agenda)
            throws IOException {

        guardarDias(agenda);
        guardarActividades(agenda);
    }


    // ==========================================
    // GUARDAR DÍAS
    // ==========================================

    public static void guardarDias(Agenda agenda)
            throws IOException {

        crearCarpeta();

        try (PrintWriter writer =
                new PrintWriter(
                        new FileWriter(
                                ARCHIVO_DIAS
                        )
                )) {

            // Encabezado
            writer.println(
                    "fecha"
            );

            for (Dia dia
                    : agenda.getDias().values()) {

                writer.println(
                        dia.getFecha()
                                .toString()
                );
            }
        }
    }


    // ==========================================
    // GUARDAR ACTIVIDADES
    // ==========================================

    public static void guardarActividades(
            Agenda agenda)
            throws IOException {

        crearCarpeta();

        try (PrintWriter writer =
                new PrintWriter(
                        new FileWriter(
                                ARCHIVO_ACTIVIDADES
                        )
                )) {

            // Encabezado del CSV
            writer.println(
                    "fecha;"
                    + "id;"
                    + "tipo;"
                    + "titulo;"
                    + "descripcion;"
                    + "horaInicio;"
                    + "horaFin;"
                    + "etiqueta;"
                    + "lugar;"
                    + "participantes"
            );

            for (Map.Entry<LocalDate, Dia> entrada
                    : agenda.getDias().entrySet()) {

                LocalDate fecha =
                        entrada.getKey();

                Dia dia =
                        entrada.getValue();

                for (Actividad actividad
                        : dia.getActividades()) {

                    String tipo;
                    String lugar = "";
                    String participantes = "";

                    // ==========================
                    // REUNIÓN
                    // ==========================

                    if (actividad instanceof Reunion) {

                        tipo = "REUNION";

                        Reunion reunion =
                                (Reunion) actividad;

                        lugar =
                                limpiar(
                                        reunion.getLugar()
                                );

                        participantes =
                                convertirParticipantesATexto(
                                        reunion
                                );

                    // ==========================
                    // EVENTO PERSONAL
                    // ==========================

                    } else {

                        tipo =
                                "EVENTO_PERSONAL";
                    }

                    String nombreEtiqueta = "";

                    if (actividad.getEtiqueta()
                            != null) {

                        nombreEtiqueta =
                                actividad
                                .getEtiqueta()
                                .getNombre();
                    }

                    writer.println(
                            fecha.toString()
                            + ";"
                            + actividad.getId()
                            + ";"
                            + tipo
                            + ";"
                            + limpiar(
                                    actividad.getTitulo()
                            )
                            + ";"
                            + limpiar(
                                    actividad
                                    .getDescripcion()
                            )
                            + ";"
                            + actividad
                                    .getHoraInicio()
                            + ";"
                            + actividad
                                    .getHoraFin()
                            + ";"
                            + limpiar(
                                    nombreEtiqueta
                            )
                            + ";"
                            + lugar
                            + ";"
                            + participantes
                    );
                }
            }
        }
    }


    // ==========================================
    // CONVERTIR PARTICIPANTES A TEXTO
    // ==========================================

    private static String convertirParticipantesATexto(
            Reunion reunion) {

        StringBuilder texto =
                new StringBuilder();

        for (Participante participante
                : reunion.getParticipantes()) {

            if (texto.length() > 0) {

                // Separa un participante de otro
                texto.append("|");
            }

            // Formato:
            // nombre,correo

            texto.append(
                    limpiarParticipante(
                            participante.getNombre()
                    )
            );

            texto.append(",");

            texto.append(
                    limpiarParticipante(
                            participante.getCorreo()
                    )
            );
        }

        return texto.toString();
    }


    // ==========================================
    // LIMPIAR TEXTO GENERAL
    // ==========================================

    private static String limpiar(
            String texto) {

        if (texto == null) {

            return "";
        }

        return texto
                .replace(";", ",")
                .replace("\n", " ")
                .replace("\r", " ");
    }


    // ==========================================
    // LIMPIAR DATOS DE PARTICIPANTES
    // ==========================================

    private static String limpiarParticipante(
            String texto) {

        if (texto == null) {

            return "";
        }

        /*
         * En participantes utilizamos:
         *
         * |  para separar participantes
         * ,  para separar nombre y correo
         *
         * Por eso evitamos guardar esos
         * caracteres dentro de los datos.
         */

        return texto
                .replace(";", " ")
                .replace("|", " ")
                .replace(",", " ")
                .replace("\n", " ")
                .replace("\r", " ");
    }


    // ==========================================
    // CARGAR TODO
    // ==========================================

    public static void cargar(Agenda agenda)
            throws IOException {

        cargarDias(agenda);
        cargarActividades(agenda);
    }


    // ==========================================
    // CARGAR DÍAS
    // ==========================================

    private static void cargarDias(
            Agenda agenda)
            throws IOException {

        File archivo =
                new File(ARCHIVO_DIAS);

        if (!archivo.exists()) {

            return;
        }

        try (BufferedReader reader =
                new BufferedReader(
                        new FileReader(
                                archivo
                        )
                )) {

            String linea;

            // Saltar encabezado
            reader.readLine();

            while ((linea =
                    reader.readLine()) != null) {

                linea =
                        linea.trim();

                if (linea.isEmpty()) {

                    continue;
                }

                try {

                    LocalDate fecha =
                            LocalDate.parse(
                                    linea
                            );

                    if (agenda.buscarDia(fecha)
                            == null) {

                        agenda.agregarDia(
                                fecha
                        );
                    }

                } catch (Exception e) {

                    System.out.println(
                            "No se pudo cargar "
                            + "el día: "
                            + linea
                    );
                }
            }
        }
    }


    // ==========================================
    // CARGAR ACTIVIDADES
    // ==========================================

    private static void cargarActividades(
            Agenda agenda)
            throws IOException {

        File archivo =
                new File(
                        ARCHIVO_ACTIVIDADES
                );

        if (!archivo.exists()) {

            return;
        }

        try (BufferedReader reader =
                new BufferedReader(
                        new FileReader(
                                archivo
                        )
                )) {

            String linea;

            // Saltar encabezado
            reader.readLine();

            while ((linea =
                    reader.readLine()) != null) {

                if (linea.trim().isEmpty()) {

                    continue;
                }

                /*
                 * -1 permite conservar
                 * columnas vacías al final.
                 *
                 * Esto es importante porque
                 * EventoPersonal no posee
                 * lugar ni participantes.
                 */

                String[] datos =
                        linea.split(
                                ";",
                                -1
                        );

                if (datos.length < 10) {

                    System.out.println(
                            "Registro inválido en "
                            + "actividades.csv: "
                            + linea
                    );

                    continue;
                }

                try {

                    // ==========================
                    // LEER DATOS
                    // ==========================

                    LocalDate fecha =
                            LocalDate.parse(
                                    datos[0]
                            );

                    int id =
                            Integer.parseInt(
                                    datos[1]
                            );

                    String tipo =
                            datos[2];

                    String titulo =
                            datos[3];

                    String descripcion =
                            datos[4];

                    LocalTime horaInicio =
                            LocalTime.parse(
                                    datos[5]
                            );

                    LocalTime horaFin =
                            LocalTime.parse(
                                    datos[6]
                            );

                    String nombreEtiqueta =
                            datos[7];

                    String lugar =
                            datos[8];

                    String participantes =
                            datos[9];


                    // ==========================
                    // BUSCAR / CREAR DÍA
                    // ==========================

                    Dia dia =
                            agenda.buscarDia(
                                    fecha
                            );

                    if (dia == null) {

                        agenda.agregarDia(
                                fecha
                        );

                        dia =
                                agenda.buscarDia(
                                        fecha
                                );
                    }


                    // ==========================
                    // CREAR ETIQUETA
                    // ==========================

                    Etiqueta etiqueta =
                            new Etiqueta(
                                    nombreEtiqueta,
                                    ""
                            );


                    // ==========================
                    // CREAR ACTIVIDAD
                    // ==========================

                    Actividad actividad;

                    if ("REUNION"
                            .equalsIgnoreCase(
                                    tipo
                            )) {

                        Reunion reunion =
                                new Reunion(
                                        id,
                                        titulo,
                                        descripcion,
                                        horaInicio,
                                        horaFin,
                                        etiqueta,
                                        lugar
                                );

                        // Reconstruir participantes
                        cargarParticipantes(
                                reunion,
                                participantes
                        );

                        actividad =
                                reunion;

                    } else if (
                            "EVENTO_PERSONAL"
                            .equalsIgnoreCase(
                                    tipo
                            )) {

                        actividad =
                                new EventoPersonal(
                                        id,
                                        titulo,
                                        descripcion,
                                        horaInicio,
                                        horaFin,
                                        etiqueta
                                );

                    } else {

                        System.out.println(
                                "Tipo de actividad "
                                + "desconocido: "
                                + tipo
                        );

                        continue;
                    }


                    // ==========================
                    // AGREGAR AL DÍA
                    // ==========================

                    dia.agregarActividad(
                            actividad
                    );

                } catch (Exception e) {

                    System.out.println(
                            "No se pudo cargar "
                            + "la actividad: "
                            + linea
                    );

                    System.out.println(
                            "Motivo: "
                            + e.getMessage()
                    );
                }
            }
        }
    }


    // ==========================================
    // RECONSTRUIR PARTICIPANTES
    // ==========================================

    private static void cargarParticipantes(
            Reunion reunion,
            String textoParticipantes) {

        if (textoParticipantes == null
                || textoParticipantes
                        .trim()
                        .isEmpty()) {

            return;
        }

        /*
         * Ejemplo recibido:
         *
         * Paula,paula@mail.cl|
         * Mauricio,mauricio@mail.cl
         */

        String[] listaParticipantes =
                textoParticipantes
                        .split("\\|");

        for (String datoParticipante
                : listaParticipantes) {

            if (datoParticipante
                    .trim()
                    .isEmpty()) {

                continue;
            }

            /*
             * Separamos solamente en 2:
             *
             * 0 = nombre
             * 1 = correo
             */

            String[] datosParticipante =
                    datoParticipante
                            .split(
                                    ",",
                                    2
                            );

            String nombre = "";

            String correo = "";

            if (datosParticipante.length
                    >= 1) {

                nombre =
                        datosParticipante[0]
                                .trim();
            }

            if (datosParticipante.length
                    >= 2) {

                correo =
                        datosParticipante[1]
                                .trim();
            }

            Participante participante =
                    new Participante(
                            nombre,
                            correo
                    );

            reunion.agregarParticipante(
                    participante
            );
        }
    }
}