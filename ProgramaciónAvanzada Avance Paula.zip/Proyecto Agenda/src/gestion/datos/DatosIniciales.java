package gestion.datos;

import gestion.clases.Agenda;
import gestion.clases.Etiqueta;
import gestion.clases.EventoPersonal;
import gestion.clases.Participante;
import gestion.clases.Reunion;
import gestion.excepciones.FechaDuplicadaException;
import gestion.excepciones.HorarioInvalidoException;

import java.time.LocalDate;
import java.time.LocalTime;

public class DatosIniciales {

    private DatosIniciales() {
        // Clase utilitaria: no necesita ser instanciada.
    }

    public static void cargar(Agenda agenda) {

        try {

            // =================================================
            // ETIQUETAS DE EJEMPLO
            // =================================================

            Etiqueta universidad = new Etiqueta(
                    "Universidad",
                    "Actividades académicas"
            );

            Etiqueta proyecto = new Etiqueta(
                    "Proyecto",
                    "Actividades relacionadas con proyectos"
            );

            Etiqueta personal = new Etiqueta(
                    "Personal",
                    "Actividades personales"
            );

            // =================================================
            // DÍAS INICIALES
            // =================================================

            LocalDate fecha1 = LocalDate.of(2026, 8, 18);
            LocalDate fecha2 = LocalDate.of(2026, 8, 20);
            LocalDate fecha3 = LocalDate.of(2026, 8, 21);

            agenda.agregarDia(fecha1);
            agenda.agregarDia(fecha2);
            agenda.agregarDia(fecha3);

            // =================================================
            // REUNIÓN DE PROYECTO
            // =================================================

            Reunion reunionProyecto = new Reunion(
                    101,
                    "Reunión de proyecto",
                    "Revisión del avance del proyecto",
                    LocalTime.of(10, 0),
                    LocalTime.of(11, 30),
                    proyecto,
                    "Sala 302"
            );

            reunionProyecto.agregarParticipante(
                    new Participante(
                            "Paula Henríquez",
                            "paula@mail.cl"
                    )
            );

            reunionProyecto.agregarParticipante(
                    new Participante(
                            "Mauricio Lavin",
                            "mauricio@mail.cl"
                    )
            );

            agenda.buscarDia(fecha1)
                    .agregarActividad(reunionProyecto);

            // =================================================
            // EVENTO PERSONAL / UNIVERSIDAD
            // =================================================

            EventoPersonal estudio = new EventoPersonal(
                    102,
                    "Estudiar Programación",
                    "Preparar evaluación de Programación Avanzada",
                    LocalTime.of(15, 0),
                    LocalTime.of(17, 0),
                    universidad
            );

            agenda.buscarDia(fecha1)
                    .agregarActividad(estudio);

            // =================================================
            // SEGUNDA REUNIÓN
            // =================================================

            Reunion reunionGrupo = new Reunion(
                    103,
                    "Reunión de grupo",
                    "Coordinar tareas pendientes",
                    LocalTime.of(9, 0),
                    LocalTime.of(10, 0),
                    proyecto,
                    "Sala 201"
            );

            reunionGrupo.agregarParticipante(
                    new Participante(
                            "Karina Madrid",
                            "karina@mail.cl"
                    )
            );

            agenda.buscarDia(fecha2)
                    .agregarActividad(reunionGrupo);

            // =================================================
            // SEGUNDO EVENTO PERSONAL
            // =================================================

            EventoPersonal actividadPersonal = new EventoPersonal(
                    104,
                    "Actividad personal",
                    "Compromiso personal",
                    LocalTime.of(18, 0),
                    LocalTime.of(19, 0),
                    personal
            );

            agenda.buscarDia(fecha3)
                    .agregarActividad(actividadPersonal);

        } catch (FechaDuplicadaException
                | HorarioInvalidoException e) {

            System.out.println(
                    "Error al cargar datos iniciales: "
                    + e.getMessage()
            );
        }
    }
}