package gestion.gui;

import gestion.clases.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ConsultarAgenda extends JFrame {

    private Agenda agenda;

    private JTextField txtInicio;
    private JTextField txtFin;
    private JTextField txtEtiqueta;

    private JTextArea area;

    public ConsultarAgenda(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Consultar Agenda");
        setSize(600, 450);
        setLocationRelativeTo(null);

        JPanel superior = new JPanel(
                new GridLayout(2, 4, 10, 10)
        );

        superior.add(
                new JLabel("Fecha inicio:")
        );

        txtInicio = new JTextField();
        superior.add(txtInicio);

        superior.add(
                new JLabel("Fecha fin:")
        );

        txtFin = new JTextField();
        superior.add(txtFin);

        superior.add(
                new JLabel("Etiqueta:")
        );

        txtEtiqueta = new JTextField();
        superior.add(txtEtiqueta);

        JButton btnConsultar =
                new JButton("Consultar");

        superior.add(btnConsultar);

        add(superior, BorderLayout.NORTH);

        area = new JTextArea();
        area.setEditable(false);

        add(
                new JScrollPane(area),
                BorderLayout.CENTER
        );

        btnConsultar.addActionListener(e ->
                consultar()
        );
    }

    private void consultar() {

        try {

            DateTimeFormatter formato =
                    DateTimeFormatter.ofPattern(
                            "dd/MM/yyyy"
                    );

            String textoInicio =
                    txtInicio.getText().trim();

            String textoFin =
                    txtFin.getText().trim();

            String etiqueta =
                    txtEtiqueta.getText().trim();

            if (textoInicio.isEmpty()
                    || textoFin.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar ambas fechas.",
                        "Datos incompletos",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            if (etiqueta.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una etiqueta.",
                        "Datos incompletos",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            LocalDate inicio =
                    LocalDate.parse(
                            textoInicio,
                            formato
                    );

            LocalDate fin =
                    LocalDate.parse(
                            textoFin,
                            formato
                    );

            if (fin.isBefore(inicio)) {

                JOptionPane.showMessageDialog(
                        this,
                        "La fecha final no puede ser anterior "
                        + "a la fecha inicial.",
                        "Rango inválido",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            List<ActividadProgramada> actividades =
                    agenda
                    .consultarActividadesPorPeriodoYEtiqueta(
                            inicio,
                            fin,
                            etiqueta
                    );

            area.setText("");

            if (actividades.isEmpty()) {

                area.setText(
                        "No se encontraron actividades."
                );

                return;
            }

            for (ActividadProgramada ap : actividades) {

                Actividad actividad =
                        ap.getActividad();

                area.append(
                        "Fecha: "
                        + ap.getFecha()
                                .format(formato)
                        + "\n"
                );

                area.append(
                        "Hora: "
                        + actividad.getHoraInicio()
                        + " - "
                        + actividad.getHoraFin()
                        + "\n"
                );

                area.append(
                        "Título: "
                        + actividad.getTitulo()
                        + "\n"
                );

                area.append(
                        "Descripción: "
                        + actividad.getDescripcion()
                        + "\n"
                );

                if (actividad.getEtiqueta() != null) {

                    area.append(
                            "Etiqueta: "
                            + actividad.getEtiqueta()
                                    .getNombre()
                            + "\n"
                    );
                }

                area.append(
                        actividad.mostrarDetalle()
                        + "\n"
                );

                area.append(
                        "-----------------------------\n"
                );
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha inválida. "
                    + "Use el formato dd/MM/yyyy.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}