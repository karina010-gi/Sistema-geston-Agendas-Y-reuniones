package gestion.gui;

import gestion.clases.Agenda;
import gestion.clases.Dia;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class BuscarDia extends JFrame {

    private Agenda agenda;
    private JTextField txtFecha;
    private JTextArea areaResultado;

    public BuscarDia(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Buscar Día");
        setSize(450, 300);
        setLocationRelativeTo(null);

        JPanel superior = new JPanel();

        superior.add(
                new JLabel("Fecha (dd/MM/yyyy):")
        );

        txtFecha = new JTextField(10);
        superior.add(txtFecha);

        JButton btnBuscar =
                new JButton("Buscar");

        superior.add(btnBuscar);

        add(superior, BorderLayout.NORTH);

        areaResultado = new JTextArea();
        areaResultado.setEditable(false);

        add(
                new JScrollPane(areaResultado),
                BorderLayout.CENTER
        );

        btnBuscar.addActionListener(e ->
                buscar()
        );
    }

    private void buscar() {

        try {

            String textoFecha =
                    txtFecha.getText().trim();

            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una fecha.",
                        "Fecha requerida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            DateTimeFormatter formato =
                    DateTimeFormatter.ofPattern(
                            "dd/MM/yyyy"
                    );

            LocalDate fecha =
                    LocalDate.parse(
                            textoFecha,
                            formato
                    );

            Dia dia =
                    agenda.buscarDia(fecha);

            if (dia == null) {

                areaResultado.setText(
                        "No se encontró el día."
                );

                return;
            }

            areaResultado.setText(
                    "DÍA ENCONTRADO\n\n"
                    + "Fecha: "
                    + dia.getFecha().format(formato)
                    + "\n"
                    + "Cantidad de actividades: "
                    + dia.getActividades().size()
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha inválida. Utilice el formato dd/MM/yyyy.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}