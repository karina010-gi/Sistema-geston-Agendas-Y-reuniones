package gestion.gui;

import gestion.clases.Agenda;
import gestion.clases.Dia;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ListarDias extends JFrame {

    private Agenda agenda;
    private JTextArea area;

    public ListarDias(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Días registrados");

        setSize(
                460,
                460
        );

        setLocationRelativeTo(null);

        setResizable(false);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );


        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal =
                new JPanel(
                        new BorderLayout(
                                0,
                                15
                        )
                );

        principal.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );


        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo =
                new JLabel(
                        "♡ Días Registrados ♡",
                        SwingConstants.CENTER
                );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        21
                )
        );

        principal.add(
                titulo,
                BorderLayout.NORTH
        );


        // ======================================
        // ÁREA DE TEXTO
        // ======================================

        area =
                new JTextArea();

        area.setEditable(false);

        area.setLineWrap(true);

        area.setWrapStyleWord(true);

        area.setMargin(
                new Insets(
                        12,
                        12,
                        12,
                        12
                )
        );

        JScrollPane scroll =
                new JScrollPane(
                        area
                );

        scroll.setVerticalScrollBarPolicy(
                JScrollPane
                .VERTICAL_SCROLLBAR_AS_NEEDED
        );

        principal.add(
                scroll,
                BorderLayout.CENTER
        );


        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                12,
                                0
                        )
                );

        JButton btnActualizar =
                new JButton(
                        "Actualizar"
                );

        JButton btnCerrar =
                new JButton(
                        "Cerrar"
                );

        panelBotones.add(
                btnActualizar
        );

        panelBotones.add(
                btnCerrar
        );

        principal.add(
                panelBotones,
                BorderLayout.SOUTH
        );


        add(
                principal
        );


        // ======================================
        // ACCIONES
        // ======================================

        btnActualizar.addActionListener(
                e -> mostrarDias()
        );

        btnCerrar.addActionListener(
                e -> dispose()
        );


        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(
                this
        );


        // ======================================
        // MOSTRAR DATOS AL ABRIR
        // ======================================

        mostrarDias();
    }


    // ==========================================
    // MOSTRAR DÍAS
    // ==========================================

    private void mostrarDias() {

        area.setText("");

        if (agenda.getDias().isEmpty()) {

            area.setText(
                    "No hay días registrados."
            );

            return;
        }

        DateTimeFormatter formato =
                DateTimeFormatter
                .ofPattern(
                        "dd/MM/yyyy"
                );


        for (LocalDate fecha
                : agenda.getDias().keySet()) {

            Dia dia =
                    agenda.buscarDia(
                            fecha
                    );

            area.append(
                    "♡ Fecha: "
                    + dia.getFecha()
                            .format(formato)
                    + "\n"
            );

            area.append(
                    "   Actividades registradas: "
                    + dia.getActividades()
                            .size()
                    + "\n"
            );

            area.append(
                    "-----------------------------------\n"
            );
        }
    }
}