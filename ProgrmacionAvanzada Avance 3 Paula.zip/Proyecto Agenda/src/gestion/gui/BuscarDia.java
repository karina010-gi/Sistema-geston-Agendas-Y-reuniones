package gestion.gui;

import gestion.clases.Agenda;
import gestion.clases.Dia;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class BuscarDia extends JFrame {

    private Agenda agenda;
    private JTextField txtFecha;
    private JTextArea areaResultado;

    public BuscarDia(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Buscar Día");

        setSize(
                470,
                380
        );

        setLocationRelativeTo(null);

        setResizable(false);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );


        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal =
                new JPanel(
                        new BorderLayout(
                                0,
                                15
                        )
                );

        principal.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );


        // ======================================
        // ENCABEZADO
        // ======================================

        JPanel encabezado =
                new JPanel();

        encabezado.setLayout(
                new BoxLayout(
                        encabezado,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel titulo =
                new JLabel(
                        "♡ Buscar Día ♡"
                );

        titulo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        20
                )
        );

        encabezado.add(
                titulo
        );

        encabezado.add(
                Box.createVerticalStrut(
                        20
                )
        );


        // ======================================
        // FILA DE BÚSQUEDA
        // ======================================

        JPanel filaBusqueda =
                new JPanel(
                        new BorderLayout(
                                10,
                                0
                        )
                );

        JLabel lblFecha =
                new JLabel(
                        "Fecha:"
                );

        txtFecha =
                new JTextField();

        JButton btnBuscar =
                new JButton(
                        "Buscar"
                );

        filaBusqueda.add(
                lblFecha,
                BorderLayout.WEST
        );

        filaBusqueda.add(
                txtFecha,
                BorderLayout.CENTER
        );

        filaBusqueda.add(
                btnBuscar,
                BorderLayout.EAST
        );

        encabezado.add(
                filaBusqueda
        );

        encabezado.add(
                Box.createVerticalStrut(
                        7
                )
        );


        // ======================================
        // TEXTO DE AYUDA
        // ======================================

        JLabel ayuda =
                new JLabel(
                        "Formato: dd/MM/yyyy"
                );

        ayuda.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        ayuda.setFont(
                new Font(
                        "SansSerif",
                        Font.PLAIN,
                        11
                )
        );

        encabezado.add(
                ayuda
        );


        principal.add(
                encabezado,
                BorderLayout.NORTH
        );


        // ======================================
        // RESULTADO
        // ======================================

        areaResultado =
                new JTextArea();

        areaResultado.setEditable(false);

        areaResultado.setLineWrap(true);

        areaResultado.setWrapStyleWord(true);

        areaResultado.setMargin(
                new Insets(
                        15,
                        15,
                        15,
                        15
                )
        );

        JScrollPane scroll =
                new JScrollPane(
                        areaResultado
                );

        principal.add(
                scroll,
                BorderLayout.CENTER
        );


        // ======================================
        // BOTÓN CERRAR
        // ======================================

        JPanel panelInferior =
                new JPanel(
                        new BorderLayout()
                );

        JButton btnCerrar =
                new JButton(
                        "Cerrar"
                );

        panelInferior.add(
                btnCerrar,
                BorderLayout.CENTER
        );

        principal.add(
                panelInferior,
                BorderLayout.SOUTH
        );


        add(
                principal
        );


        // ======================================
        // ACCIONES
        // ======================================

        btnBuscar.addActionListener(
                e -> buscar()
        );

        btnCerrar.addActionListener(
                e -> dispose()
        );


        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(
                this
        );
    }


    // ==========================================
    // BUSCAR DÍA
    // ==========================================

    private void buscar() {

        try {

            String textoFecha =
                    txtFecha
                    .getText()
                    .trim();


            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una fecha.",
                        "Fecha requerida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            DateTimeFormatter formato =
                    DateTimeFormatter
                    .ofPattern(
                            "dd/MM/yyyy"
                    );


            LocalDate fecha =
                    LocalDate.parse(
                            textoFecha,
                            formato
                    );


            Dia dia =
                    agenda.buscarDia(
                            fecha
                    );


            // ==================================
            // NO ENCONTRADO
            // ==================================

            if (dia == null) {

                areaResultado.setText(
                        "♡ Día no encontrado\n\n"
                        + "No existe un día registrado "
                        + "con la fecha "
                        + fecha.format(formato)
                        + "."
                );

                return;
            }


            // ==================================
            // ENCONTRADO
            // ==================================

            areaResultado.setText(
                    "♡ DÍA ENCONTRADO ♡\n\n"
                    + "Fecha: "
                    + dia.getFecha()
                            .format(formato)
                    + "\n\n"
                    + "Cantidad de actividades: "
                    + dia.getActividades()
                            .size()
            );


        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha inválida.\n"
                    + "Utilice el formato dd/MM/yyyy.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}