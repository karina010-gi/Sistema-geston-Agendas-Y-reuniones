package gestion.gui;

import gestion.clases.*;
import gestion.excepciones.HorarioInvalidoException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AgregarActividad extends JFrame {

    private Agenda agenda;

    private JTextField txtFecha;
    private JTextField txtId;
    private JTextField txtTitulo;
    private JTextField txtDescripcion;
    private JTextField txtInicio;
    private JTextField txtFin;
    private JTextField txtEtiqueta;
    private JTextField txtLugar;

    private JComboBox<String> comboTipo;


    public AgregarActividad(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Agregar Actividad");

        setSize(
                560,
                620
        );

        setLocationRelativeTo(null);

        setResizable(false);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );


        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal =
                new JPanel(
                        new BorderLayout(
                                0,
                                15
                        )
                );

        principal.setBorder(
                new EmptyBorder(
                        20,
                        30,
                        25,
                        30
                )
        );


        // ======================================
        // TÍTULO
        // ======================================

        JLabel titulo =
                new JLabel(
                        "♡ Agregar Actividad ♡",
                        SwingConstants.CENTER
                );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        22
                )
        );

        principal.add(
                titulo,
                BorderLayout.NORTH
        );


        // ======================================
        // PANEL DE CAMPOS
        // ======================================

        JPanel formulario =
                new JPanel(
                        new GridLayout(
                                9,
                                2,
                                12,
                                12
                        )
                );


        // FECHA

        formulario.add(
                new JLabel(
                        "Fecha:"
                )
        );

        txtFecha =
                new JTextField();

        formulario.add(
                txtFecha
        );


        // TIPO

        formulario.add(
                new JLabel(
                        "Tipo:"
                )
        );

        comboTipo =
                new JComboBox<>(
                        new String[]{
                            "Evento Personal",
                            "Reunión"
                        }
                );

        formulario.add(
                comboTipo
        );


        // ID

        formulario.add(
                new JLabel(
                        "ID:"
                )
        );

        txtId =
                new JTextField();

        formulario.add(
                txtId
        );


        // TÍTULO

        formulario.add(
                new JLabel(
                        "Título:"
                )
        );

        txtTitulo =
                new JTextField();

        formulario.add(
                txtTitulo
        );


        // DESCRIPCIÓN

        formulario.add(
                new JLabel(
                        "Descripción:"
                )
        );

        txtDescripcion =
                new JTextField();

        formulario.add(
                txtDescripcion
        );


        // HORA INICIO

        formulario.add(
                new JLabel(
                        "Hora inicio:"
                )
        );

        txtInicio =
                new JTextField();

        formulario.add(
                txtInicio
        );


        // HORA FIN

        formulario.add(
                new JLabel(
                        "Hora fin:"
                )
        );

        txtFin =
                new JTextField();

        formulario.add(
                txtFin
        );


        // ETIQUETA

        formulario.add(
                new JLabel(
                        "Etiqueta:"
                )
        );

        txtEtiqueta =
                new JTextField();

        formulario.add(
                txtEtiqueta
        );


        // LUGAR

        formulario.add(
                new JLabel(
                        "Lugar:"
                )
        );

        txtLugar =
                new JTextField();

        formulario.add(
                txtLugar
        );


        // ======================================
        // BLOQUE CENTRAL
        // ======================================

        JPanel centro =
                new JPanel();

        centro.setLayout(
                new BoxLayout(
                        centro,
                        BoxLayout.Y_AXIS
                )
        );

        centro.add(
                formulario
        );

        centro.add(
                Box.createVerticalStrut(
                        10
                )
        );


        // ======================================
        // TEXTO DE AYUDA
        // ======================================

        JLabel ayuda =
                new JLabel(
                        "<html><center>"
                        + "Fecha: dd/MM/yyyy"
                        + " &nbsp;&nbsp; | &nbsp;&nbsp; "
                        + "Hora: HH:mm"
                        + "<br>"
                        + "El lugar solo es obligatorio para reuniones."
                        + "</center></html>"
                );

        ayuda.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        ayuda.setFont(
                new Font(
                        "SansSerif",
                        Font.PLAIN,
                        11
                )
        );

        centro.add(
                ayuda
        );

        principal.add(
                centro,
                BorderLayout.CENTER
        );


        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                12,
                                0
                        )
                );

        JButton btnAgregar =
                new JButton(
                        "Agregar"
                );

        JButton btnCerrar =
                new JButton(
                        "Cerrar"
                );

        panelBotones.add(
                btnAgregar
        );

        panelBotones.add(
                btnCerrar
        );

        principal.add(
                panelBotones,
                BorderLayout.SOUTH
        );


        add(
                principal
        );


        // ======================================
        // ACCIONES
        // ======================================

        btnAgregar.addActionListener(
                e -> agregarActividad()
        );

        btnCerrar.addActionListener(
                e -> dispose()
        );


        // ======================================
        // COMPORTAMIENTO DEL CAMPO LUGAR
        // ======================================

        actualizarCampoLugar();

        comboTipo.addActionListener(
                e -> actualizarCampoLugar()
        );


        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(
                this
        );
    }


    // ==========================================
    // ACTIVAR / DESACTIVAR LUGAR
    // ==========================================

    private void actualizarCampoLugar() {

        boolean esReunion =
                comboTipo.getSelectedItem()
                .equals("Reunión");

        txtLugar.setEnabled(
                esReunion
        );

        if (!esReunion) {

            txtLugar.setText("");
        }
    }


    // ==========================================
    // LIMPIAR CAMPOS
    // ==========================================

    private void limpiarCampos() {

        txtFecha.setText("");
        txtId.setText("");
        txtTitulo.setText("");
        txtDescripcion.setText("");
        txtInicio.setText("");
        txtFin.setText("");
        txtEtiqueta.setText("");
        txtLugar.setText("");

        comboTipo.setSelectedIndex(0);

        actualizarCampoLugar();
    }


    // ==========================================
    // AGREGAR ACTIVIDAD
    // ==========================================

    private void agregarActividad() {

        try {

            // ==================================
            // FECHA
            // ==================================

            String textoFecha =
                    txtFecha
                    .getText()
                    .trim();

            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una fecha.",
                        "Fecha requerida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            DateTimeFormatter formatoFecha =
                    DateTimeFormatter
                    .ofPattern(
                            "dd/MM/yyyy"
                    );


            LocalDate fecha =
                    LocalDate.parse(
                            textoFecha,
                            formatoFecha
                    );


            Dia dia =
                    agenda.buscarDia(
                            fecha
                    );


            if (dia == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Primero debes crear ese día.",
                        "Día no encontrado",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            // ==================================
            // ID
            // ==================================

            String textoId =
                    txtId
                    .getText()
                    .trim();


            if (textoId.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar un ID.",
                        "ID requerido",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            int id =
                    Integer.parseInt(
                            textoId
                    );


            if (id <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "El ID debe ser mayor que cero.",
                        "ID inválido",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }


            if (agenda.existeActividadConId(id)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ya existe una actividad con el ID "
                        + id + ".",
                        "ID duplicado",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }


            // ==================================
            // TÍTULO
            // ==================================

            String titulo =
                    txtTitulo
                    .getText()
                    .trim();


            if (titulo.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar un título.",
                        "Título requerido",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            // ==================================
            // DESCRIPCIÓN
            // ==================================

            String descripcion =
                    txtDescripcion
                    .getText()
                    .trim();


            // ==================================
            // HORARIOS
            // ==================================

            String textoInicio =
                    txtInicio
                    .getText()
                    .trim();

            String textoFin =
                    txtFin
                    .getText()
                    .trim();


            if (textoInicio.isEmpty()
                    || textoFin.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar la hora de inicio "
                        + "y la hora de término.",
                        "Horario requerido",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            LocalTime inicio =
                    LocalTime.parse(
                            textoInicio
                    );


            LocalTime fin =
                    LocalTime.parse(
                            textoFin
                    );


            // ==================================
            // ETIQUETA
            // ==================================

            String nombreEtiqueta =
                    txtEtiqueta
                    .getText()
                    .trim();


            if (nombreEtiqueta.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una etiqueta.",
                        "Etiqueta requerida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            Etiqueta etiqueta =
                    new Etiqueta(
                            nombreEtiqueta,
                            ""
                    );


            // ==================================
            // CREAR ACTIVIDAD
            // ==================================

            Actividad actividad;


            if (comboTipo
                    .getSelectedItem()
                    .equals("Reunión")) {

                String lugar =
                        txtLugar
                        .getText()
                        .trim();


                if (lugar.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Debe ingresar un lugar "
                            + "para la reunión.",
                            "Lugar requerido",
                            JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }


                actividad =
                        new Reunion(
                                id,
                                titulo,
                                descripcion,
                                inicio,
                                fin,
                                etiqueta,
                                lugar
                        );

            } else {

                actividad =
                        new EventoPersonal(
                                id,
                                titulo,
                                descripcion,
                                inicio,
                                fin,
                                etiqueta
                        );
            }


            // ==================================
            // AGREGAR AL DÍA
            // ==================================

            dia.agregarActividad(
                    actividad
            );


            JOptionPane.showMessageDialog(
                    this,
                    "Actividad agregada correctamente."
            );


            limpiarCampos();


        } catch (HorarioInvalidoException e) {

            JOptionPane.showMessageDialog(
                    this,
                    e.getMessage(),
                    "Horario inválido",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "El ID debe ser un número entero.",
                    "ID inválido",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Revisa la fecha y las horas ingresadas.\n"
                    + "Fecha: dd/MM/yyyy\n"
                    + "Hora: HH:mm",
                    "Datos inválidos",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}