package gestion.gui;

import gestion.clases.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ListarActividades extends JFrame {

    private Agenda agenda;

    private JTextField txtFecha;
    private JTextArea area;


    public ListarActividades(Agenda agenda) {

        this.agenda = agenda;

        setTitle("Listar Actividades");

        setSize(
                560,
                500
        );

        setLocationRelativeTo(null);

        setResizable(false);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );


        // ======================================
        // PANEL PRINCIPAL
        // ======================================

        JPanel principal =
                new JPanel(
                        new BorderLayout(
                                0,
                                15
                        )
                );

        principal.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );


        // ======================================
        // ENCABEZADO
        // ======================================

        JPanel encabezado =
                new JPanel();

        encabezado.setLayout(
                new BoxLayout(
                        encabezado,
                        BoxLayout.Y_AXIS
                )
        );


        JLabel titulo =
                new JLabel(
                        "♡ Actividades del Día ♡"
                );

        titulo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        21
                )
        );


        encabezado.add(
                titulo
        );

        encabezado.add(
                Box.createVerticalStrut(
                        20
                )
        );


        // ======================================
        // BÚSQUEDA POR FECHA
        // ======================================

        JPanel filaBusqueda =
                new JPanel(
                        new BorderLayout(
                                10,
                                0
                        )
                );


        JLabel lblFecha =
                new JLabel(
                        "Fecha:"
                );


        txtFecha =
                new JTextField();


        JButton btnMostrar =
                new JButton(
                        "Mostrar"
                );


        filaBusqueda.add(
                lblFecha,
                BorderLayout.WEST
        );

        filaBusqueda.add(
                txtFecha,
                BorderLayout.CENTER
        );

        filaBusqueda.add(
                btnMostrar,
                BorderLayout.EAST
        );


        encabezado.add(
                filaBusqueda
        );

        encabezado.add(
                Box.createVerticalStrut(
                        7
                )
        );


        JLabel ayuda =
                new JLabel(
                        "Formato: dd/MM/yyyy"
                );

        ayuda.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        ayuda.setFont(
                new Font(
                        "SansSerif",
                        Font.PLAIN,
                        11
                )
        );


        encabezado.add(
                ayuda
        );


        principal.add(
                encabezado,
                BorderLayout.NORTH
        );


        // ======================================
        // ÁREA DE RESULTADOS
        // ======================================

        area =
                new JTextArea();

        area.setEditable(false);

        area.setLineWrap(true);

        area.setWrapStyleWord(true);

        area.setMargin(
                new Insets(
                        15,
                        15,
                        15,
                        15
                )
        );


        JScrollPane scroll =
                new JScrollPane(
                        area
                );


        principal.add(
                scroll,
                BorderLayout.CENTER
        );


        // ======================================
        // BOTÓN CERRAR
        // ======================================

        JPanel panelInferior =
                new JPanel(
                        new BorderLayout()
                );


        JButton btnCerrar =
                new JButton(
                        "Cerrar"
                );


        panelInferior.add(
                btnCerrar,
                BorderLayout.CENTER
        );


        principal.add(
                panelInferior,
                BorderLayout.SOUTH
        );


        add(
                principal
        );


        // ======================================
        // ACCIONES
        // ======================================

        btnMostrar.addActionListener(
                e -> listar()
        );


        btnCerrar.addActionListener(
                e -> dispose()
        );


        // ======================================
        // ESTILO PASTEL
        // ======================================

        EstiloUI.aplicar(
                this
        );
    }


    // ==========================================
    // LISTAR ACTIVIDADES
    // ==========================================

    private void listar() {

        try {

            String textoFecha =
                    txtFecha
                    .getText()
                    .trim();


            if (textoFecha.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Debe ingresar una fecha.",
                        "Fecha requerida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }


            DateTimeFormatter formato =
                    DateTimeFormatter
                    .ofPattern(
                            "dd/MM/yyyy"
                    );


            LocalDate fecha =
                    LocalDate.parse(
                            textoFecha,
                            formato
                    );


            Dia dia =
                    agenda.buscarDia(
                            fecha
                    );


            // ==================================
            // DÍA NO EXISTE
            // ==================================

            if (dia == null) {

                area.setText(
                        "♡ Día no encontrado\n\n"
                        + "No existe un día registrado "
                        + "con la fecha "
                        + fecha.format(formato)
                        + "."
                );

                return;
            }


            // ==================================
            // SIN ACTIVIDADES
            // ==================================

            if (dia.getActividades().isEmpty()) {

                area.setText(
                        "♡ Sin actividades ♡\n\n"
                        + "No hay actividades registradas "
                        + "para el día "
                        + fecha.format(formato)
                        + "."
                );

                return;
            }


            // ==================================
            // MOSTRAR ACTIVIDADES
            // ==================================

            area.setText(
                    "♡ ACTIVIDADES DEL "
                    + fecha.format(formato)
                    + " ♡\n\n"
            );


            for (Actividad actividad
                    : dia.getActividades()) {

                area.append(
                        "ID: "
                        + actividad.getId()
                        + "\n"
                );

                area.append(
                        "Título: "
                        + actividad.getTitulo()
                        + "\n"
                );

                area.append(
                        "Horario: "
                        + actividad.getHoraInicio()
                        + " - "
                        + actividad.getHoraFin()
                        + "\n"
                );


                if (actividad.getEtiqueta() != null) {

                    area.append(
                            "Etiqueta: "
                            + actividad
                            .getEtiqueta()
                            .getNombre()
                            + "\n"
                    );
                }


                area.append(
                        actividad.mostrarDetalle()
                        + "\n"
                );


                area.append(
                        "\n"
                        + "----------------------------------------"
                        + "\n\n"
                );
            }


        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fecha inválida.\n"
                    + "Utilice el formato dd/MM/yyyy.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}