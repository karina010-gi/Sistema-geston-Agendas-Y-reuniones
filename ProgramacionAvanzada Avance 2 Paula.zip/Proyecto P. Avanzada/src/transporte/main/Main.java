package transporte.main;

import transporte.servicio.Empresa;
import transporte.modelo.*;
import transporte.excepciones.*;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Empresa empresa = new Empresa("Mi Empresa");
        Scanner sc = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\n===== MENÚ =====");
            System.out.println("1. Agregar Bus");
            System.out.println("2. Mostrar Buses");
            System.out.println("3. Agregar Viaje");
            System.out.println("4. Mostrar Viajes");
            System.out.println("5. Agregar Pasajero a Viaje");
            System.out.println("6. Verificar Rentabilidad");
            System.out.println("0. Salir");

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    System.out.print("Patente: ");
                    String patente = sc.next();

                    System.out.print("Capacidad: ");
                    int capacidad = sc.nextInt();

                    empresa.agregarBus(new Bus(patente, capacidad));
                    System.out.println("Bus agregado");
                    break;

                case 2:
                    empresa.mostrarBuses();
                    break;

                case 3:
                    try {
                        System.out.print("ID: ");
                        int id = sc.nextInt();

                        sc.nextLine(); // limpiar buffer
                        System.out.print("Destino: ");
                        String destino = sc.next();

                        System.out.print("Costo Para Empresa: ");
                        double costo = sc.nextDouble();

                        System.out.print("Valor Pasaje: ");
                        double precio = sc.nextDouble();

                        System.out.print("Patente bus: ");
                        String pat = sc.next();

                        Bus bus = empresa.obtenerBuses().get(pat);

                        if (bus != null) {
                            empresa.agregarViaje(new Viaje(id, destino, costo, precio, bus));
                            System.out.println("Viaje agregado");
                        } else {
                            System.out.println("Bus no existe");
                        }

                    } catch (Exception e) {
                        System.out.println("Error en los datos");
                        sc.nextLine();
                    }
                    break;

                case 4:
                    empresa.mostrarViajes();
                    break;

                case 5:
                    try {
                        System.out.print("ID viaje: ");
                        int idViaje = sc.nextInt();

                        Viaje viaje = empresa.buscarViaje(idViaje);

                        if (viaje != null) {

                            sc.nextLine();
                            System.out.print("Nombre pasajero: ");
                            String nombre = sc.nextLine();

                            System.out.print("RUT: ");
                            String rut = sc.nextLine();

                            System.out.print("ID pasajero: ");
                            int idPasajero = sc.nextInt();

                            viaje.agregarPasajero(nombre, rut, idPasajero);

                            System.out.println("Pasajero agregado");

                        } else {
                            System.out.println("Viaje no encontrado");
                        }

                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        sc.nextLine();
                    }
                    break;

                case 6:
                    try {
                        System.out.print("ID viaje: ");
                        int idVer = sc.nextInt();

                        Viaje v = empresa.buscarViaje(idVer);

                        if (v != null) {
                            v.verificarRentabilidad();
                            System.out.println("El viaje es rentable");
                        } else {
                            System.out.println("Viaje no encontrado");
                        }

                    } catch (ViajeNoRentableException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 0:
                    System.out.println("?Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida");
            }

        } while (opcion != 0);

        sc.close();
    }
}