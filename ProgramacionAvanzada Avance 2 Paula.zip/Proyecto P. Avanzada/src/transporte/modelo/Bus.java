package transporte.modelo;

import java.util.ArrayList;
import transporte.excepciones.BusLlenoException;

public class Bus {

    private String patente;
    private int capacidad;
    private ArrayList<Pasajero> pasajeros;

    public Bus(String patente, int capacidad) {
        this.patente = patente;
        this.capacidad = capacidad;
        this.pasajeros = new ArrayList<>();
    }

    public String getPatente() {
        return patente;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        if (capacidad > 0) {
            this.capacidad = capacidad;
        }
    }

    public ArrayList<Pasajero> getPasajeros() {
        return pasajeros;
    }

    public void agregarPasajero(Pasajero p) throws BusLlenoException {
        if (pasajeros.size() < capacidad) {
            pasajeros.add(p);
        } else {
            throw new BusLlenoException("❌ El bus está lleno");
        }
    }

    @Override
    public String toString() {
        return "Bus " + patente +
               " | Capacidad: " + capacidad +
               " | Ocupación: " + pasajeros.size();
    }
}