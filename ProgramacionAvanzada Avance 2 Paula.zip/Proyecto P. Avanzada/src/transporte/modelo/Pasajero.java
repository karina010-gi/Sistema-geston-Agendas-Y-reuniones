package transporte.modelo;

public class Pasajero extends Persona {

    private String rut;
    private int id;

    public Pasajero(String nombre, String rut, int id) {
        super(nombre);
        this.rut = rut;
        this.id = id;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if (rut != null && !rut.isEmpty()) {
            this.rut = rut;
        }
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Pasajero: " + nombre + " - RUT: " + rut + " - ID: " + id;
    }
}