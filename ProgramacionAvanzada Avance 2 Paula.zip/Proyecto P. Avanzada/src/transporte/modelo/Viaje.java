package transporte.modelo;

import java.util.ArrayList;
import transporte.excepciones.ViajeNoRentableException;

public class Viaje {

    private int id;
    private String destino;
    private double costoViaje;
    private double precioPasaje;
    private ArrayList<Pasajero> pasajeros;
    private Bus bus;

    public Viaje(int id, String destino, double costoViaje, double precioPasaje, Bus bus) {
        this.id = id;
        this.destino = destino;
        this.costoViaje = costoViaje;
        this.precioPasaje = precioPasaje;
        this.bus = bus;
        this.pasajeros = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        if (destino != null && !destino.isEmpty()) {
            this.destino = destino;
        }
    }

    public double getCostoViaje() {
        return costoViaje;
    }

    public void setCostoViaje(double costoViaje) {
        if (costoViaje >= 0) {
            this.costoViaje = costoViaje;
        }
    }

    public double getPrecioPasaje() {
        return precioPasaje;
    }

    public void setPrecioPasaje(double precioPasaje) {
        if (precioPasaje >= 0) {
            this.precioPasaje = precioPasaje;
        }
    }

    public ArrayList<Pasajero> getPasajeros() {
        return pasajeros;
    }

    public Bus getBus() {
        return bus;
    }

    public void agregarPasajero(Pasajero p) throws Exception {
        pasajeros.add(p);
        bus.agregarPasajero(p);
    }

    public void agregarPasajero(String nombre, String rut, int id) {
        Pasajero p = new Pasajero(nombre, rut, id);
        try {
            agregarPasajero(p);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public double calcularIngresos() {
        return pasajeros.size() * precioPasaje;
    }

    public boolean esRentable() {
        return calcularIngresos() >= costoViaje;
    }

    public void verificarRentabilidad() throws ViajeNoRentableException {
        if (!esRentable()) {
            throw new ViajeNoRentableException("Viaje no rentable");
        }
    }

    public void limpiarPasajeros() {
        pasajeros.clear();
    }

    @Override
    public String toString() {
        return "Viaje " + id +
               " : " + destino +
               " - Ingresos: " + calcularIngresos() +
               " - Costo: " + costoViaje +
               " - Rentable: " + esRentable();
    }
}