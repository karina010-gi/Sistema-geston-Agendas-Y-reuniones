package transporte.servicio;

import transporte.modelo.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Empresa {

    private String nombre;
    private ArrayList<Viaje> viajes;
    private HashMap<String, Bus> buses;

    public Empresa(String nombre) {
        this.nombre = nombre;
        this.viajes = new ArrayList<>();
        this.buses = new HashMap<>();
    }

    public void agregarBus(Bus b) {
        buses.put(b.getPatente(), b);
    }

    public void agregarViaje(Viaje v) {
        viajes.add(v);
    }

    public Viaje buscarViaje(int id) {
        for (Viaje v : viajes) {
            if (v.getId() == id) {
                return v;
            }
        }
        return null;
    }

    public void mostrarViajes() {
        for (Viaje v : viajes) {
            System.out.println(v);
        }
    }

    public void mostrarBuses() {
        for (Bus b : buses.values()) {
            System.out.println(b);
        }
    }

    public HashMap<String, Bus> obtenerBuses() {
        return buses;
    }

    public ArrayList<Viaje> getViajes() {
        return viajes;
    }
}